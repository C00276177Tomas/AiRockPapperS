# Rock-Papper-Scissors > 2023-09-19 9:17am
https://universe.roboflow.com/seeed-studio-ovcjn/rock-papper-scissors

Provided by a Roboflow user
License: CC BY 4.0

